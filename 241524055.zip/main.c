#include "LinkedList.h"

int main() {
    LinkedList L1, L2;

    initList(&L1);
    initList(&L2);

    // Memasukkan data ke dalam L1
    insertSorted(&L1, "Zaky", 80);
    insertSorted(&L1, "Rifqi", 75);
    insertSorted(&L1, "Aldi", 60);
    insertSorted(&L1, "Budi", 90);
    insertSorted(&L1, "Rifqi", 85); // Nama sama, akan diuji pada L2

    // Menampilkan isi L1 secara ascending
    printf("List L1 (Ascending berdasarkan Nama):\n");
    printList(&L1);

    // Menampilkan isi L1 secara descending berdasarkan nilai
    printf("\nList L1 (Descending berdasarkan Nilai):\n");
    printListDescending(&L1);

    // Menampilkan jumlah elemen
    printf("\nJumlah mahasiswa dalam L1: %d\n", countElements(&L1));

    // Menyalin elemen dengan nilai > 70 ke L2
    copyAbove70(&L1, &L2);

    // Menampilkan isi L2 sebelum penghapusan duplikat
    printf("\nList L2 sebelum penghapusan duplikat:\n");
    printList(&L2);

    // Menghapus nama yang duplikat di L2
    removeDuplicates(&L2);

    // Menampilkan isi L2 setelah penghapusan duplikat
    printf("\nList L2 setelah penghapusan duplikat:\n");
    printList(&L2);

    // Menghapus kedua list
    destroyList(&L1);
    destroyList(&L2);

    return 0;
}