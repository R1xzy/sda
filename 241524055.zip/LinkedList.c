#include "LinkedList.h"

// Constructor
void initList(LinkedList* list) {
    list->head = NULL;
}

// Destructor
void destroyList(LinkedList* list) {
    Node* current = list->head;
    while (current) {
        Node* temp = current;
        current = current->next;
        free(temp);
    }
    list->head = NULL;
}

// Validator
int isEmpty(LinkedList* list) {
    return list->head == NULL;
}

// Menyisipkan elemen secara ascending berdasarkan Nama
void insertSorted(LinkedList* list, char* nama, int nilai) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    strcpy(newNode->nama, nama);
    newNode->nilai = nilai;
    newNode->next = NULL;

    if (isEmpty(list) || strcmp(nama, list->head->nama) < 0) {
        newNode->next = list->head;
        list->head = newNode;
        return;
    }

    Node* current = list->head;
    while (current->next && strcmp(nama, current->next->nama) > 0) {
        current = current->next;
    }
    
    newNode->next = current->next;
    current->next = newNode;
}

// Menampilkan List secara Ascending
void printList(LinkedList* list) {
    Node* temp = list->head;
    while (temp) {
        printf("%s - %d\n", temp->nama, temp->nilai);
        temp = temp->next;
    }
}

// Menampilkan List secara Descending berdasarkan Nilai
void printListDescending(LinkedList* list) {
    int n = countElements(list);
    Node* array[n];
    Node* temp = list->head;

    for (int i = 0; i < n; i++) {
        array[i] = temp;
        temp = temp->next;
    }

    for (int i = n - 1; i >= 0; i--) {
        printf("%s - %d\n", array[i]->nama, array[i]->nilai);
    }
}

// Menghitung jumlah elemen dalam List
int countElements(LinkedList* list) {
    int count = 0;
    Node* temp = list->head;
    while (temp) {
        count++;
        temp = temp->next;
    }
    return count;
}

// Menyalin elemen dengan nilai > 70 ke L2
void copyAbove70(LinkedList* src, LinkedList* dest) {
    Node* temp = src->head;
    while (temp) {
        if (temp->nilai > 70) {
            insertSorted(dest, temp->nama, temp->nilai);
        }
        temp = temp->next;
    }
}

// Menghapus duplikasi nama dalam List
void removeDuplicates(LinkedList* list) {
    Node* current = list->head;
    while (current && current->next) {
        if (strcmp(current->nama, current->next->nama) == 0) {
            Node* temp = current->next;
            current->next = current->next->next;
            free(temp);
        } else {
            current = current->next;
        }
    }
}