#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Struktur Node
typedef struct Node {
    char nama[50];
    int nilai;
    struct Node* next;
} Node;

// Struktur List
typedef struct {
    Node* head;
} LinkedList;

// Fungsi utama (5 sekawan)
void initList(LinkedList* list);         // Constructor
void destroyList(LinkedList* list);      // Destructor
int isEmpty(LinkedList* list);           // Validator
void insertSorted(LinkedList* list, char* nama, int nilai); // Get/Set (menyisipkan secara ascending)
void printList(LinkedList* list);        // PrintObject

// Fungsi tambahan
void printListDescending(LinkedList* list);
int countElements(LinkedList* list);
void copyAbove70(LinkedList* src, LinkedList* dest);
void removeDuplicates(LinkedList* list);

#endif